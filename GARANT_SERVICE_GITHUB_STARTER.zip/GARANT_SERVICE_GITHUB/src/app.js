const $ = id => document.getElementById(id);
const KEY = "garant_service_demo_records";
const getRecords = () => JSON.parse(localStorage.getItem(KEY) || "[]");
const saveRecords = records => localStorage.setItem(KEY, JSON.stringify(records));
const today = new Date();
$("date").min = today.toISOString().slice(0,10);
$("date").value = today.toISOString().slice(0,10);
for(let h=9;h<=18;h++){for(const m of ["00","30"]){const t=`${String(h).padStart(2,"0")}:${m}`;const o=document.createElement("option");o.value=t;o.textContent=t;$("time").append(o)}}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelectorAll(".tab,.page").forEach(x=>x.classList.remove("active"));
 btn.classList.add("active");$(btn.dataset.page).classList.add("active");render();
}));
$("bookingForm").addEventListener("submit",e=>{
 e.preventDefault();
 const records=getRecords();
 const day=$("date").value;
 const count=records.filter(r=>r.date===day).length+1;
 const record={id:Date.now(),number:count,name:$("customer").value.trim(),phone:$("phone").value.trim(),service:$("service").value,date:day,time:$("time").value,status:"Ожидает"};
 records.push(record);saveRecords(records);render();
 alert(`Запись создана! Ваш номер очереди: ${count}`);
 document.querySelector('[data-page="status"]').click();
});
$("adminLogin").addEventListener("click",()=>{
 if($("adminCode").value!=="GARANT2026"){alert("Неверный демо-код");return}
 $("adminRecords").innerHTML=getRecords().map(r=>`<div class="record"><strong>№${r.number} · ${r.name}</strong><br>${r.service}<br>${r.date} ${r.time}<br>${r.phone}<br>Статус: ${r.status}</div>`).join("")||'<div class="empty">Записей пока нет.</div>';
});
function render(){
 const records=getRecords().slice().reverse();
 const latest=records[0];
 $("latest").innerHTML=latest?`<div class="record"><strong>Ваш номер: №${latest.number}</strong><br>${latest.service}<br>${latest.date} в ${latest.time}<br>Статус: ${latest.status}</div>`:'Пока нет записей. Сначала оформите запись.';
 $("historyList").innerHTML=records.length?records.map(r=>`<div class="record"><strong>№${r.number} · ${r.service}</strong><br>${r.date} ${r.time}<br>Статус: ${r.status}</div>`).join(""):'История пока пуста.';
}
render();