# GARANT SERVICE

Starter project for an Android APK using Capacitor and GitHub Actions.

## Build APK
1. Upload these files to a GitHub repository on branch `main`.
2. Open **Actions**.
3. Select **Build GARANT SERVICE APK**.
4. Press **Run workflow** (or push a commit).
5. When the workflow succeeds, open its run and download artifact `GARANT-SERVICE-APK`.
6. Unzip the artifact; install `app-debug.apk` on Android.

## Important
This is a starter/demo. The booking data is stored only in the current device's browser storage.
It is NOT yet a shared live queue between customers and does not have secure administrator authentication.
Before real customer use, connect a backend database and server-side admin authentication.

## iPhone
The same Capacitor web project can be used as the basis for iOS, but an iPhone app is not an APK.
An iOS build requires macOS/Xcode and Apple signing/distribution setup.
