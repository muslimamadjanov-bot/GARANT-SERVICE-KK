const fs = require("fs");
const path = require("path");
const src = path.join(__dirname, "..", "src");
const out = path.join(__dirname, "..", "www");
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const name of fs.readdirSync(src)) {
  fs.copyFileSync(path.join(src, name), path.join(out, name));
}
console.log("Web app copied to www/");
